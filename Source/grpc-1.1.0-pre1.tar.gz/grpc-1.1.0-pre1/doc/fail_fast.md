Moved to wait-for-ready.md
