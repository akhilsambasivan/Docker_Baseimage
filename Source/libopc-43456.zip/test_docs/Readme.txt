List of sample docs:

OOXMLI1.docx and OOXMLI4.docx from http://www.ecma-international.org/publications/standards/Ecma-376.htm: 
helloworld.pptx
stream.zip


