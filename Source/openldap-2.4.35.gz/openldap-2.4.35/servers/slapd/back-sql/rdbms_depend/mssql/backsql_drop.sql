drop table ldap_attr_mappings
GO

drop table ldap_referrals
GO

drop table ldap_entry_objclasses
GO

drop table ldap_entries
GO

drop table ldap_oc_mappings
GO
