DROP TABLE persons;
DROP TABLE institutes;
DROP TABLE documents;
DROP TABLE authors_docs;
DROP TABLE phones;
DROP TABLE referrals;
DROP FUNCTION create_person ();
DROP FUNCTION update_person_cn (varchar, int);
DROP FUNCTION add_phone (varchar, int);
DROP FUNCTION create_doc ();
DROP FUNCTION create_o ();
DROP FUNCTION create_referral ();

